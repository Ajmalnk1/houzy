<?php
/**
 * Theme Functions
 *
 * @package DTtheme
 * @author DesignThemes
 * @link http://wedesignthemes.com
 */
define( 'HOUZY_THEME_DIR', get_template_directory() );
define( 'HOUZY_THEME_URI', get_template_directory_uri() );
define( 'HOUZY_THEME_SETTINGS', 'houzy-settings' );

if (function_exists ('wp_get_theme')) :
	$themeData = wp_get_theme();
	define( 'HOUZY_THEME_NAME', $themeData->get('Name'));
	define( 'HOUZY_THEME_VERSION', $themeData->get('Version'));
endif;

/* ---------------------------------------------------------------------------
 * Load default theme options
 * ---------------------------------------------------------------------------*/
require_once HOUZY_THEME_DIR .'/inc/class-theme-options.php';

/* ---------------------------------------------------------------------------
 * Loads Customizer
 * ---------------------------------------------------------------------------*/
require_once( HOUZY_THEME_DIR .'/inc/customizer/lib/class-fontawesome.php' );
require_once( HOUZY_THEME_DIR .'/inc/customizer/lib/class-font-families.php' );
require_once( HOUZY_THEME_DIR .'/inc/customizer/lib/class-customizer-sanitizes.php' );
require_once( HOUZY_THEME_DIR .'/inc/customizer/index.php' );
require_once( HOUZY_THEME_DIR .'/inc/metabox/index.php' );
function houzy_defaults() {}

/* ---------------------------------------------------------------------------
 * Widget Area
 * ---------------------------------------------------------------------------*/
require_once HOUZY_THEME_DIR .'/inc/widget-area/class-widget-area.php';

/* ---------------------------------------------------------------------------
 * Dynamic CSS
 * ---------------------------------------------------------------------------*/
require_once HOUZY_THEME_DIR .'/inc/class-theme-dynamic-css.php';
require_once HOUZY_THEME_DIR .'/inc/class-theme-dynamic-skin-css.php';

/* ---------------------------------------------------------------------------
 * Loads Theme Textdomain
 * ---------------------------------------------------------------------------*/ 
define( 'HOUZY_LANG_DIR', HOUZY_THEME_DIR. '/languages' );
load_theme_textdomain( 'houzy', HOUZY_LANG_DIR );

/* ---------------------------------------------------------------------------
 * Loads Theme Functions
 * ---------------------------------------------------------------------------*/

// Functions --------------------------------------------------------------------
require_once( HOUZY_THEME_DIR .'/framework/register-functions.php' );

// Header -----------------------------------------------------------------------
require_once( HOUZY_THEME_DIR .'/framework/register-head.php' );

// Hooks ------------------------------------------------------------------------
require_once( HOUZY_THEME_DIR .'/framework/register-hooks.php' );

// Backend Menu Walker
require_once( HOUZY_THEME_DIR .'/framework/register-frontend-menu-walker.php' );

// Post Functions ---------------------------------------------------------------
require_once( HOUZY_THEME_DIR .'/framework/register-post-functions.php' );
new houzy_post_functions;

// Plugins ---------------------------------------------------------------------- 
require_once( HOUZY_THEME_DIR .'/framework/register-plugins.php' );

// Register Templates -----------------------------------------------------------
require_once( HOUZY_THEME_DIR .'/framework/register-templates.php' );

// Register Gutenberg -----------------------------------------------------------
require_once( HOUZY_THEME_DIR .'/framework/register-gutenberg-editor.php' );