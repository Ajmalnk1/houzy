<?php
/**
 * Additional JS Section
 */
	$wp_customize->add_section( 
		new HOUZY_WP_Customize_Section(
			$wp_customize,
			'additionaljs-section',
			array(
				'title'    => esc_html__('Additional JS', 'houzy'),
				'priority' => 135
			)
		)
	);

		/**
		 * Option : Additional JS
		 */
			$wp_customize->add_setting(
				HOUZY_THEME_SETTINGS . '[additional-js]', array (
					'default'           => houzy_get_option( 'additional-js' ),
					'type'              => 'option',
					'sanitize_callback' => 'wp_filter_nohtml_kses',
				)
			);

			$wp_customize->add_control(
				new HOUZY_Customize_Control(
					$wp_customize, HOUZY_THEME_SETTINGS . '[additional-js]', array (
						'type'    => 'textarea',
						'label'   => esc_html__( 'Additional JS', 'houzy'),
						'description'   => esc_html__( 'Add your own JS code here to customize your theme.', 'houzy'),
						'section' => 'additionaljs-section',
					)
				)
			);