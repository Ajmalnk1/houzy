<?php
/**
 * Site Skin Main Section
 */
$wp_customize->add_section( 
	new HOUZY_WP_Customize_Section(
		$wp_customize,
		'site-skin-main-section',
		array(
			'title'    => esc_html__('Site Skin', 'houzy'),
			'priority' => 10
		)
	)
);


/**
 * Option : Primary Color
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[primary-color]', array(
			'default'           => houzy_get_option( 'primary-color' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_hex_color' ),
		)
	);

	$wp_customize->add_control( new HOUZY_Customize_Control_Color(
		$wp_customize, HOUZY_THEME_SETTINGS . '[primary-color]', array(
			'label'   => esc_html__( 'Primary Color', 'houzy' ),
			'section' => 'site-skin-main-section',
		)
	));

/**
 * Option : Secondary Color
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[secondary-color]', array(
			'default'           => houzy_get_option( 'secondary-color' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_hex_color' ),
		)
	);

	$wp_customize->add_control( new HOUZY_Customize_Control_Color(
		$wp_customize, HOUZY_THEME_SETTINGS . '[secondary-color]', array(
			'label'   => esc_html__( 'Secondary Color', 'houzy' ),
			'section' => 'site-skin-main-section',
		)
	));

/**
 * Option : Tertiary Color
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[tertiary-color]', array(
			'default'           => houzy_get_option( 'tertiary-color' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_hex_color' ),
		)
	);

	$wp_customize->add_control( new HOUZY_Customize_Control_Color(
		$wp_customize, HOUZY_THEME_SETTINGS . '[tertiary-color]', array(
			'label'   => esc_html__( 'Tertiary Color', 'houzy' ),
			'section' => 'site-skin-main-section',
		)
	));
	
/**
 * Option :  Body BG Color
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[body-bg-color]', array(
			'default'           => houzy_get_option( 'body-bg-color' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_hex_color' ),
		)
	);

	$wp_customize->add_control( new HOUZY_Customize_Control_Color(
		$wp_customize, HOUZY_THEME_SETTINGS . '[body-bg-color]', array(
			'label'   => esc_html__( 'Site BG Color', 'houzy' ),
			'section' => 'site-skin-main-section',
		)
	));