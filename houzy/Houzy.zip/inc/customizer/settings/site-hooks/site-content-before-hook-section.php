<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option : Enable Content Before Hook
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[enable-content-before-hook]', array(
			'default'           => houzy_get_option( 'enable-content-before-hook' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control_Switch(
			$wp_customize, HOUZY_THEME_SETTINGS . '[enable-content-before-hook]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Content Before Hook', 'houzy'),
				'section' => 'site-content-before-hook-section',
				'description' => esc_html__('YES! to enable content before hook.', 'houzy'),
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'houzy' ),
					'off' => esc_attr__( 'No', 'houzy' )
				)
			)
		)
	);

/**
 * Option : Content Before Hook
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[content-before-hook]', array(
			'default'           => houzy_get_option( 'content-before-hook' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_html' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[content-before-hook]', array(
				'type'    	  => 'textarea',
				'section'     => 'site-content-before-hook-section',
				'label'       => esc_html__( 'Content Before Hook', 'houzy' ),
				'description' => sprintf( esc_html__('Paste your content before hook, Executes before the opening %s tag.', 'houzy'), '&lt;#primary&gt;' )
			)
		)
	);