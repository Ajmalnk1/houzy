<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option : Enable Tracking Code
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[enable-analytics-code]', array(
			'default'           => houzy_get_option( 'enable-analytics-code' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control_Switch(
			$wp_customize, HOUZY_THEME_SETTINGS . '[enable-analytics-code]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Tracking Code', 'houzy'),
				'section' => 'site-tracking-code-section',
				'description' => esc_html__('YES! to enable site tracking code.', 'houzy'),
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'houzy' ),
					'off' => esc_attr__( 'No', 'houzy' )
				)
			)
		)
	);

/**
 * Option : Tracking Code
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[analytics-code]', array(
			'default'           => houzy_get_option( 'analytics-code' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_html' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[analytics-code]', array(
				'type'    	  => 'textarea',
				'section'     => 'site-tracking-code-section',
				'label'       => esc_html__( 'Google Analytics Tracking Code', 'houzy' ),
				'description' => esc_html__('Either enter your Google tracking id (UA-XXXXX-X) here. If you want to offer your visitors the option to stop being tracked you can place the shortcode [dt_sc_privacy_google_tracking] somewhere on your site', 'houzy'),
			)
		)
	);