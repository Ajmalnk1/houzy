<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option : Enable Bottom Hook
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[enable-bottom-hook]', array(
			'default'           => houzy_get_option( 'enable-bottom-hook' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control_Switch(
			$wp_customize, HOUZY_THEME_SETTINGS . '[enable-bottom-hook]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Bottom Hook', 'houzy'),
				'section' => 'site-bottom-hook-section',
				'description' => esc_html__('YES! to enable bottom hook.', 'houzy'),
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'houzy' ),
					'off' => esc_attr__( 'No', 'houzy' )
				)
			)
		)
	);

/**
 * Option : Bottom Hook
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[bottom-hook]', array(
			'default'           => houzy_get_option( 'bottom-hook' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_html' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[bottom-hook]', array(
				'type'    	  => 'textarea',
				'section'     => 'site-bottom-hook-section',
				'label'       => esc_html__( 'Bottom Hook', 'houzy' ),
				'description' => esc_html__('Paste your bottom hook, Executes after the closing &lt;/body&gt; tag.', 'houzy'),
			)
		)
	);