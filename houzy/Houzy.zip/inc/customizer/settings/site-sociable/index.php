<?php
/**
 * Site Sociable Main Section
 */
$wp_customize->add_section( 
	new HOUZY_WP_Customize_Section(
		$wp_customize,
		'site-sociable-main-section',
		array(
			'title'    => esc_html__('Sociable', 'houzy'),
			'priority' => 10
		)
	)
);

/**
 * Option : Delicious
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-delicious]', array(
			'default'           => houzy_get_option( 'sociable-delicious' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-delicious]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Delicious', 'houzy' ),
				'description' => esc_html__('Put sociable url, wants to show on front-end.', 'houzy'),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Delicious', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Deviantart
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-deviantart]', array(
			'default'           => houzy_get_option( 'sociable-deviantart' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-deviantart]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Deviantart', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Deviantart', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Digg
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-digg]', array(
			'default'           => houzy_get_option( 'sociable-digg' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-digg]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Digg', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Digg', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Dribbble
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-dribbble]', array(
			'default'           => houzy_get_option( 'sociable-dribbble' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-dribbble]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Dribbble', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Dribbble', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Envelope
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-envelope]', array(
			'default'           => houzy_get_option( 'sociable-envelope' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-envelope]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Envelope', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Envelope', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Facebook
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-facebook]', array(
			'default'           => houzy_get_option( 'sociable-facebook' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-facebook]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Facebook', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Facebook', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Flickr
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-flickr]', array(
			'default'           => houzy_get_option( 'sociable-flickr' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-flickr]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Flickr', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Flickr', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Google Plus
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-google-plus]', array(
			'default'           => houzy_get_option( 'sociable-google-plus' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-google-plus]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Google Plus', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Google Plus', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : GTalk
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-gtalk]', array(
			'default'           => houzy_get_option( 'sociable-gtalk' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-gtalk]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'GTalk', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'GTalk', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Instagram
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-instagram]', array(
			'default'           => houzy_get_option( 'sociable-instagram' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-instagram]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Instagram', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Instagram', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Lastfm
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-lastfm]', array(
			'default'           => houzy_get_option( 'sociable-lastfm' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-lastfm]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Lastfm', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Lastfm', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Linkedin
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-linkedin]', array(
			'default'           => houzy_get_option( 'sociable-linkedin' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-linkedin]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Linkedin', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Linkedin', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Pinterest
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-pinterest]', array(
			'default'           => houzy_get_option( 'sociable-pinterest' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-pinterest]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Pinterest', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Pinterest', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Reddit
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-reddit]', array(
			'default'           => houzy_get_option( 'sociable-reddit' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-reddit]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Reddit', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Reddit', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : RSS
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-rss]', array(
			'default'           => houzy_get_option( 'sociable-rss' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-rss]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'RSS', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'RSS', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Skype
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-skype]', array(
			'default'           => houzy_get_option( 'sociable-skype' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-skype]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Skype', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Skype', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Stumbleupon
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-stumbleupon]', array(
			'default'           => houzy_get_option( 'sociable-stumbleupon' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-stumbleupon]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Stumbleupon', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Stumbleupon', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Tumblr
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-tumblr]', array(
			'default'           => houzy_get_option( 'sociable-tumblr' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-tumblr]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Tumblr', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Tumblr', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Twitter
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-twitter]', array(
			'default'           => houzy_get_option( 'sociable-twitter' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-twitter]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Twitter', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Twitter', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Viadeo
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-viadeo]', array(
			'default'           => houzy_get_option( 'sociable-viadeo' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-viadeo]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Viadeo', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Viadeo', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Vimeo
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-vimeo]', array(
			'default'           => houzy_get_option( 'sociable-vimeo' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-vimeo]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Vimeo', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Vimeo', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Yahoo
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-yahoo]', array(
			'default'           => houzy_get_option( 'sociable-yahoo' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-yahoo]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Yahoo', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Yahoo', 'houzy' ),
				),
			)
		)
	);

/**
 * Option : Youtube
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[sociable-youtube]', array(
			'default'           => houzy_get_option( 'sociable-youtube' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[sociable-youtube]', array(
				'type'    	  => 'text',
				'section'     => 'site-sociable-main-section',
//				'label'       => esc_html__( 'Youtube', 'houzy' ),
				'input_attrs' => array(
					'placeholder' => esc_html__( 'Youtube', 'houzy' ),
				),
			)
		)
	);