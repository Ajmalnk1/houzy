<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option :H1 Typo
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[h1-typo]', array(
			'default'           =>  houzy_get_option( 'h1-typo' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control_Typography(
			$wp_customize, HOUZY_THEME_SETTINGS . '[h1-typo]', array(
				'type'    => 'dt-typography',
				'section' => 'site-h1-section',
				'label'   => esc_html__( 'H1 Tag', 'houzy'),
			)
		)
	);

/**
 * Option : H1 Color
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[h1-color]', array(
			'default'           => houzy_get_option( 'h1-color' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_hex_color' ),
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[h1-color]', array(
				'label'   => esc_html__( 'Color', 'houzy' ),
				'section' => 'site-h1-section',
			)
		)
	);	