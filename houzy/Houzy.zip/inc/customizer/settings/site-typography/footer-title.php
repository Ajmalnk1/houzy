<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

	/**
	 * Footer Title Section 
	 */
	$wp_customize->add_section( 
		new HOUZY_WP_Customize_Section(
			$wp_customize,
			'site-footer-title-section',
			array(
				'title'    => esc_html__('Title', 'houzy'),
				'panel'    => 'site-footer-main-panel',
			)
		)
	);
	
	/**
	 * Option :Footer Title Typo
	 */
		$wp_customize->add_setting(
			HOUZY_THEME_SETTINGS . '[footer-title-typo]', array(
				'default'           =>  houzy_get_option( 'footer-title-typo' ),
				'type'              => 'option',
				'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
			)
		);

		$wp_customize->add_control(
			new HOUZY_Customize_Control_Typography(
				$wp_customize, HOUZY_THEME_SETTINGS . '[footer-title-typo]', array(
					'type'    => 'dt-typography',
					'section' => 'site-footer-title-section',
					'label'   => esc_html__( 'Typography', 'houzy'),
				)
			)
		);

	/**
	 * Option : Footer Title Color
	 */
		$wp_customize->add_setting(
			HOUZY_THEME_SETTINGS . '[footer-title-color]', array(
				'default'           => houzy_get_option( 'footer-title-color' ),
				'type'              => 'option',
				'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_hex_color' ),
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize, HOUZY_THEME_SETTINGS . '[footer-title-color]', array(
					'label'   => esc_html__( 'Color', 'houzy' ),
					'section' => 'site-footer-title-section',
				)
			)
		);