<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Footer Content Section 
 */
$wp_customize->add_section( 
	new HOUZY_WP_Customize_Section(
		$wp_customize,
		'site-footer-content-section',
		array(
			'title'    => esc_html__('Content', 'houzy'),
			'panel'    => 'site-footer-main-panel',
		)
	)
);

	/**
	 * Option :Footer Content Typo
	 */
		$wp_customize->add_setting(
			HOUZY_THEME_SETTINGS . '[footer-content-typo]', array(
				'default'           =>  houzy_get_option( 'footer-content-typo' ),
				'type'              => 'option',
				'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),				
			)
		);

		$wp_customize->add_control(
			new HOUZY_Customize_Control_Typography(
				$wp_customize, HOUZY_THEME_SETTINGS . '[footer-content-typo]', array(
					'type'    => 'dt-typography',
					'section' => 'site-footer-content-section',
					'label'   => esc_html__( 'Typography', 'houzy'),
				)
			)
		);

	/**
	 * Option : Footer Content Color
	 */
		$wp_customize->add_setting(
			HOUZY_THEME_SETTINGS . '[footer-content-color]', array(
				'default'           => houzy_get_option( 'footer-content-color' ),
				'type'              => 'option',
				'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_hex_color' ),
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize, HOUZY_THEME_SETTINGS . '[footer-content-color]', array(
					'label'   => esc_html__( 'Color', 'houzy' ),
					'section' => 'site-footer-content-section',
				)
			)
		);

	/**
	 * Option : Footer Content Anchor Color
	 */
		$wp_customize->add_setting(
			HOUZY_THEME_SETTINGS . '[footer-content-a-color]', array(
				'default'           => houzy_get_option( 'footer-content-a-color' ),
				'type'              => 'option',
				'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_hex_color' ),
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize, HOUZY_THEME_SETTINGS . '[footer-content-a-color]', array(
					'label'   => esc_html__( 'Anchor Color', 'houzy' ),
					'section' => 'site-footer-content-section',
				)
			)
		);

	/**
	 * Option : Footer Content Anchor hover Color
	 */
		$wp_customize->add_setting(
			HOUZY_THEME_SETTINGS . '[footer-content-a-hover-color]', array(
				'default'           => houzy_get_option( 'footer-content-a-hover-color' ),
				'type'              => 'option',
				'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_hex_color' ),
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Color_Control(
				$wp_customize, HOUZY_THEME_SETTINGS . '[footer-content-a-hover-color]', array(
					'label'   => esc_html__( 'Anchor Hover Color', 'houzy' ),
					'section' => 'site-footer-content-section',
				)
			)
		);