<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option : Post Elements
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[post-elements-position]', array(
			'default'           => houzy_get_option( 'post-elements-position' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_multi_choices' ),
		)
	);

    $wp_customize->add_control( new HOUZY_Customize_Control_Sortable(
		$wp_customize, HOUZY_THEME_SETTINGS . '[post-elements-position]', array(
			'type' => 'dt-sortable',
			'label' => esc_html__( 'Post Elements Positioning', 'houzy'),
			'section' => 'site-post-single-section',
			'choices' => apply_filters( 'houzy_single_post_elements_options', array(
				'feature_image'	=> esc_html__('Feature Image', 'houzy'),
				'title'      	=> esc_html__('Title', 'houzy'),
				'content'    	=> esc_html__('Content', 'houzy'),
				'meta_group' 	=> esc_html__('Meta Group', 'houzy'),
				'navigation'    => esc_html__('Navigation', 'houzy'),
				'author_bio' 	=> esc_html__('Author Bio', 'houzy'),
				'comment_box' 	=> esc_html__('Comment Box', 'houzy'),
				'related_posts' => esc_html__('Related Posts', 'houzy'),
				'author'		=> esc_html__('Author', 'houzy'),
				'date'     		=> esc_html__('Date', 'houzy'),
				'comments' 		=> esc_html__('Comments', 'houzy'),
				'categories'    => esc_html__('Categories', 'houzy'),
				'tags'  		=> esc_html__('Tags', 'houzy'),
				'social_share'  => esc_html__('Social Share', 'houzy'),
				'likes_views'   => esc_html__('Likes & Views', 'houzy'),
				'related_article' 	=> esc_html__('Related Article( Only Fixed )', 'houzy'),
			)),
        )
    ));

/**
 * Option : Meta Elements
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[post-meta-position]', array(
			'default'           => houzy_get_option( 'post-meta-position' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_multi_choices' ),
		)
	);

    $wp_customize->add_control( new HOUZY_Customize_Control_Sortable(
		$wp_customize, HOUZY_THEME_SETTINGS . '[post-meta-position]', array(
			'type' => 'dt-sortable',
			'label' => esc_html__( 'Meta Group Positioning', 'houzy'),
			'section' => 'site-post-single-section',
			'choices' => apply_filters( 'houzy_single_post_meta_elements_options', array(
				'author'		=> esc_html__('Author', 'houzy'),
				'date'     		=> esc_html__('Date', 'houzy'),
				'comments' 		=> esc_html__('Comments', 'houzy'),
				'categories'    => esc_html__('Categories', 'houzy'),
				'tags'  		=> esc_html__('Tags', 'houzy'),
				'social_share'  => esc_html__('Social Share', 'houzy'),
				'likes_views'   => esc_html__('Likes & Views', 'houzy'),
			))
        )
    ));

/**
 * Option : Post Related Title
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[post-related-title]', array(
			'default'           => houzy_get_option( 'post-related-title' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_html' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[post-related-title]', array(
				'type'    	  => 'text',
				'section'     => 'site-post-single-section',
				'label'       => esc_html__( 'Related Posts Section Title', 'houzy' ),
				'description' => esc_html__('Put the related posts section title here', 'houzy'),
				'input_attrs' => array(
					'value'	=> esc_html__('Related Posts', 'houzy'),
				)
			)
		)
	);

/**
 * Option : Related Columns
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[post-related-columns]', array(
			'default'           => houzy_get_option( 'post-related-columns' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

    $wp_customize->add_control( new HOUZY_Customize_Control_Radio_Image(
		$wp_customize, HOUZY_THEME_SETTINGS . '[post-related-columns]', array(
			'type' => 'dt-radio-image',
			'label' => esc_html__( 'Columns', 'houzy'),
			'section' => 'site-post-single-section',
			'choices' => apply_filters( 'houzy_single_related_columns_options', array(
				'one-column' => array(
					'label' => esc_html__( 'One Column', 'houzy' ),
					'path' => HOUZY_THEME_URI . '/inc/customizer/assets/images/one-column.png'
				),
				'one-half-column' => array(
					'label' => esc_html__( 'One Half Column', 'houzy' ),
					'path' => HOUZY_THEME_URI . '/inc/customizer/assets/images/one-half-column.png'
				),
				'one-third-column' => array(
					'label' => esc_html__( 'One Third Column', 'houzy' ),
					'path' => HOUZY_THEME_URI . '/inc/customizer/assets/images/one-third-column.png'
				),
			)),
        )
    ));

/**
 * Option : Related Count
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[post-related-count]', array(
			'default'           => houzy_get_option( 'post-related-count' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_number' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[post-related-count]', array(
				'type'    	  => 'text',
				'section'     => 'site-post-single-section',
				'label'       => esc_html__( 'No.of Posts to Show', 'houzy' ),
				'description' => esc_html__('Put the no.of related posts to show', 'houzy'),
				'input_attrs' => array(
					'value'	=> 3,
				),
			)
		)
	);

/**
 * Option : Enable Excerpt
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[enable-related-excerpt]', array(
			'default'           => houzy_get_option( 'enable-related-excerpt' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control_Switch(
			$wp_customize, HOUZY_THEME_SETTINGS . '[enable-related-excerpt]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Excerpt Text', 'houzy'),
				'section' => 'site-post-single-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'houzy' ),
					'off' => esc_attr__( 'No', 'houzy' )
				)
			)
		)
	);

/**
 * Option : Excerpt Text
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[post-related-excerpt]', array(
			'default'           => houzy_get_option( 'post-related-excerpt' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_number' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control(
			$wp_customize, HOUZY_THEME_SETTINGS . '[post-related-excerpt]', array(
				'type'    	  => 'text',
				'section'     => 'site-post-single-section',
				'label'       => esc_html__( 'Excerpt Length', 'houzy' ),
				'description' => esc_html__('Put Excerpt Length', 'houzy'),
				'input_attrs' => array(
					'value'	=> 25,
				),
				'dependency' => array( 'enable-related-excerpt', '==', 'true' ),
			)
		)
	);

/**
 * Option : Related Carousel
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[enable-related-carousel]', array(
			'default'           => houzy_get_option( 'enable-related-carousel' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control_Switch(
			$wp_customize, HOUZY_THEME_SETTINGS . '[enable-related-carousel]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Enable Carousel', 'houzy'),
				'description' => esc_html__('YES! to enable carousel related posts', 'houzy'),
				'section' => 'site-post-single-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'houzy' ),
					'off' => esc_attr__( 'No', 'houzy' )
				)
			)
		)
	);

/**
 * Option : Related Carousel Nav
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[related-carousel-nav]', array(
			'default'           => houzy_get_option( 'related-carousel-nav' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control( new HOUZY_Customize_Control(
		$wp_customize, HOUZY_THEME_SETTINGS . '[related-carousel-nav]', array(
			'type'    => 'select',
			'section' => 'site-post-single-section',
			'label'   => esc_html__( 'Navigation Style', 'houzy' ),
			'choices' => array(
				'' 			 => esc_html__('None', 'houzy'),
				'navigation' => esc_html__('Navigations', 'houzy'),
				'pager'   	 => esc_html__('Pager', 'houzy'),
			),
			'description' => esc_html__('Choose navigation style to display related post carousel.', 'houzy'),
			'dependency' => array( 'enable-related-carousel', '==', 'true' ),
		)
	));

/**
 * Option : Image Lightbox
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[enable-image-lightbox]', array(
			'default'           => houzy_get_option( 'enable-image-lightbox' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_tweek' ),
		)
	);

	$wp_customize->add_control(
		new HOUZY_Customize_Control_Switch(
			$wp_customize, HOUZY_THEME_SETTINGS . '[enable-image-lightbox]', array(
				'type'    => 'dt-switch',
				'label'   => esc_html__( 'Feature Image Lightbox', 'houzy'),
				'description' => esc_html__('YES! to enable lightbox for feature image. Will not work in "Overlay" style.', 'houzy'),
				'section' => 'site-post-single-section',
				'choices' => array(
					'on'  => esc_attr__( 'Yes', 'houzy' ),
					'off' => esc_attr__( 'No', 'houzy' )
				)
			)
		)
	);

/**
 * Option : Comment List Style
 */
	$wp_customize->add_setting(
		HOUZY_THEME_SETTINGS . '[post-comments-list-style]', array(
			'default'           => houzy_get_option( 'post-comments-list-style' ),
			'type'              => 'option',
			'sanitize_callback' => array( 'HOUZY_Customizer_Sanitizes', 'sanitize_choices' ),
		)
	);

	$wp_customize->add_control( new HOUZY_Customize_Control(
		$wp_customize, HOUZY_THEME_SETTINGS . '[post-comments-list-style]', array(
			'type'    => 'select',
			'section' => 'site-post-single-section',
			'label'   => esc_html__( 'Comments List Style', 'houzy' ),
			'choices' => array(
			  'rounded' 	=> esc_html__('Rounded', 'houzy'),
			  'square'   	=> esc_html__('Square', 'houzy'),
			),
			'description' => esc_html__('Choose comments list style to display single post.', 'houzy'),
		)
	));