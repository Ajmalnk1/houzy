<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// -----------------------------------------
// Detect plugin...
// -----------------------------------------
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

// -----------------------------------------
// Layer Sliders
// -----------------------------------------
function dtm_framework_layersliders() {
  $layerslider = array(  esc_html__('Select a slider','houzy') );

  if( class_exists('LS_Sliders') ) {

    $sliders = LS_Sliders::find(array('limit' => 50));

    if(!empty($sliders)) {
      foreach($sliders as $key => $item){
        $layerslider[ $item['id'] ] = $item['name'];
      }
    }
  }

  return $layerslider;
}

// -----------------------------------------
// Revolution Sliders
// -----------------------------------------
function dtm_framework_revolutionsliders() {
  $revolutionslider = array( '' => esc_html__('Select a slider','houzy') );

  if( class_exists('RevSlider') ) {
    $sld = new RevSlider();
    $sliders = $sld->getArrSliders();
    if(!empty($sliders)){
      foreach($sliders as $key => $item) {
        $revolutionslider[$item->getAlias()] = $item->getTitle();
      }
    }
  }

  return $revolutionslider;  
}

// -----------------------------------------
// Meta Layout Section
// -----------------------------------------

$page_layout_options = array(
  'global-site-layout' 	 => DTM_URL . 'images/admin-option.png',
  'content-full-width'   => DTM_URL . 'images/without-sidebar.png',
  'with-left-sidebar'    => DTM_URL . 'images/left-sidebar.png',
  'with-right-sidebar'   => DTM_URL . 'images/right-sidebar.png'
);

// Custom Page Layout Options Filter
$page_layout_options = apply_filters( 'houzy_custom_page_layout_options', $page_layout_options  );

$meta_layout_section =array(
  'name'  => 'layout_section',
  'title' => esc_html__('Layout', 'houzy'),
  'icon'  => 'fa fa-columns',
  'fields' =>  array(
    array(
      'id'  => 'layout',
      'type' => 'image_select',
      'title' => esc_html__('Page Layout', 'houzy' ),
      'options'      => $page_layout_options,
      'default'      => 'global-site-layout',
      'attributes'   => array( 'data-depend-id' => 'page-layout' )
    ),
    array(
      'id'        => 'show-standard-sidebar-left',
      'type'      => 'switcher',
      'title'     => esc_html__('Show Standard Left Sidebar', 'houzy' ),
      'dependency'=> array( 'page-layout', 'any', 'with-left-sidebar' ),
	  'default'	  => true,
    ),
    array(
      'id'        => 'widget-area-left',
      'type'      => 'select',
      'title'     => esc_html__('Choose Left Widget Areas', 'houzy' ),
      'class'     => 'chosen',
      'options'   => houzy_customizer_custom_widgets(),
      'attributes'  => array( 
        'multiple'  => 'multiple',
        'data-placeholder' => esc_html__('Select Left Widget Areas','houzy'),
        'style' => 'width: 400px;'
      ),
      'dependency'  => array( 'page-layout', 'any', 'with-left-sidebar' ),
    ),
    array(
      'id'          => 'show-standard-sidebar-right',
      'type'        => 'switcher',
      'title'       => esc_html__('Show Standard Right Sidebar', 'houzy' ),
      'dependency'  => array( 'page-layout', 'any', 'with-right-sidebar' ),
	  'default'	  	=> true,
    ),
    array(
      'id'        => 'widget-area-right',
      'type'      => 'select',
      'title'     => esc_html__('Choose Right Widget Areas', 'houzy' ),
      'class'     => 'chosen',
      'options'   => houzy_customizer_custom_widgets(),
      'attributes'    => array( 
        'multiple' => 'multiple',
        'data-placeholder' => esc_html__('Select Right Widget Areas','houzy'),
        'style' => 'width: 400px;'
      ),
      'dependency'  => array( 'page-layout', 'any', 'with-right-sidebar' ),
    )
  )
);

// -----------------------------------------
// Meta Breadcrumb Section
// -----------------------------------------
$meta_breadcrumb_section = array(
  'name'  => 'breadcrumb_section',
  'title' => esc_html__('Breadcrumb', 'houzy'),
  'icon'  => 'fa fa-sitemap',
  'fields' =>  array(

    array(
      'id'  => 'breadcrumb-option',
      'type' => 'image_select',
      'title' => esc_html__('Breadcrumb Option', 'houzy' ),
      'options'      => array(
        'global-option'   => DTM_URL . 'images/admin-option.png',
		    'individual-option' => DTM_URL . 'images/individual-option.png',
      ),
      'default'      => 'global-option',
      'attributes'   => array( 'data-depend-id' => 'breadcrumb-option' )
    ),
    array(
      'id'         => 'enable-sub-title',
      'type'       => 'switcher',
      'title'      => esc_html__('Show Breadcrumb', 'houzy' ),
      'default'    => true,
      'dependency' => array( 'breadcrumb-option', 'any', 'individual-option' ),
    ),
    array(
      'id'         => 'enable-dark-bg',
      'type'       => 'switcher',
      'title'      => esc_html__('Dark BG?', 'houzy' ),
      'default'    => true,
      'dependency' => array( 'breadcrumb-option', 'any', 'individual-option' ),
    ),    
    array(
    	'id'                 => 'breadcrumb_position',
	    'type'               => 'select',
      'title'              => esc_html__('Position', 'houzy' ),
      'options'            => array(
        'header-top-absolute' => esc_html__('Behind the Header','houzy'),
        'header-top-relative' => esc_html__('Default','houzy'),
	  	),
		  'default'            => 'header-top-relative',	
      'dependency'         => array( 'enable-sub-title|breadcrumb-option', '==|any', 'true|individual-option' ),
    ),    
    array(
      'id'         => 'breadcrumb_background',
      'type'       => 'background',
      'title'      => esc_html__('Background', 'houzy' ),
      'dependency' => array( 'enable-sub-title|breadcrumb-option', '==|any', 'true|individual-option' ),
    )
    
  )
);

// -----------------------------------------
// Meta Slider Section
// -----------------------------------------
$meta_slider_section = array(
  'name'  => 'slider_section',
  'title' => esc_html__('Slider', 'houzy'),
  'icon'  => 'fa fa-slideshare',
  'fields' =>  array(
    array(
      'id'           => 'slider-notice',
      'type'         => 'notice',
      'class'        => 'danger',
      'content'      => esc_html__('Slider tab works only if breadcrumb disabled.','houzy'),
      'class'        => 'margin-30 cs-danger'
    ),

    array(
      'id'           => 'show_slider',
      'type'         => 'switcher',
      'title'        => esc_html__('Show Slider', 'houzy' ),
    ),
    array(
    	'id'                 => 'slider_position',
      'type'               => 'select',
      'title'              => esc_html__('Position', 'houzy' ),
      'options'            => array(
        'header-top-relative'     => esc_html__('Top Header Relative','houzy'),
        'header-top-absolute'    => esc_html__('Top Header Absolute','houzy'),
        'bottom-header' 	   => esc_html__('Bottom Header','houzy'),
      ),
      'default'            => 'bottom-header',
      'dependency'         => array( 'show_slider', '==', 'true' ),
   ),
   array(
      'id'                 => 'slider_type',
      'type'               => 'select',
      'title'              => esc_html__('Slider', 'houzy' ),
      'options'            => array(
        ''                 => esc_html__('Select a slider','houzy'),
        'layerslider'      => esc_html__('Layer slider','houzy'),
        'revolutionslider' => esc_html__('Revolution slider','houzy'),
        'customslider'     => esc_html__('Custom Slider Shortcode','houzy'),
      ),
      'validate' => 'required',
      'dependency'         => array( 'show_slider', '==', 'true' ),
    ),

    array(
      'id'          => 'layerslider_id',
      'type'        => 'select',
      'title'       => esc_html__('Layer Slider', 'houzy' ),
      'options'     => dtm_framework_layersliders(),
      'validate'    => 'required',
      'dependency'         => array( 'show_slider|slider_type', '==|==', 'true|layerslider' ),
    ),

    array(
      'id'          => 'revolutionslider_id',
      'type'        => 'select',
      'title'       => esc_html__('Revolution Slider', 'houzy' ),
      'options'     => dtm_framework_revolutionsliders(),
      'validate'    => 'required',
      'dependency'         => array( 'show_slider|slider_type', '==|==', 'true|revolutionslider' ),
    ),

    array(
      'id'          => 'customslider_sc',
      'type'        => 'textarea',
      'title'       => esc_html__('Custom Slider Code', 'houzy' ),
      'validate'    => 'required',
      'dependency'         => array( 'show_slider|slider_type', '==|==', 'true|customslider' ),
    ),
  )  
);

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options = array();

// -----------------------------------------
// Page Metabox Options                    -
// -----------------------------------------
array_push( $meta_layout_section['fields'], array(
  'id'        => 'enable-sticky-sidebar',
  'type'      => 'switcher',
  'title'     => esc_html__('Enable Sticky Sidebar', 'houzy' ),
  'dependency'  => array( 'page-layout', 'any', 'with-left-sidebar,with-right-sidebar' )
) );

$page_settings = array(
  $meta_layout_section,
  $meta_breadcrumb_section,
  $meta_slider_section,
  array(
    'name'   => 'sidenav_template_section',
    'title'  => esc_html__('Side Navigation Template', 'houzy'),
    'icon'   => 'fa fa-th-list',
    'fields' =>  array(
      array(
        'id'      => 'sidenav-tpl-notice',
        'type'    => 'notice',
        'class'   => 'success',
        'content' => esc_html__('Side Navigation Tab Works only if page template set to Side Navigation Template in Page Attributes','houzy'),
        'class'   => 'margin-30 cs-success',      
      ),
      array(
        'id'      => 'sidenav-style',
        'type'    => 'select',
        'title'   => esc_html__('Side Navigation Style', 'houzy' ),
        'options' => array(
          'type1'  => esc_html__('Type1','houzy'),
          'type2'  => esc_html__('Type2','houzy'),
          'type3'  => esc_html__('Type3','houzy'),
          'type4'  => esc_html__('Type4','houzy'),
          'type5'  => esc_html__('Type5','houzy')
        ),
      ),
      array(
        'id'    => 'sidenav-align',
        'type'  => 'switcher',
        'title' => esc_html__('Align Right', 'houzy' ),
        'info'  => esc_html__('YES! to align right of side navigation.','houzy')
      ),
      array(
        'id'    => 'sidenav-sticky',
        'type'  => 'switcher',
        'title' => esc_html__('Sticky Side Navigation', 'houzy' ),
        'info'  => esc_html__('YES! to sticky side navigation content.','houzy')
      ),
      array(
        'id'    => 'enable-sidenav-content',
        'type'  => 'switcher',
        'title' => esc_html__('Show Content', 'houzy' ),
        'info'  => esc_html__('YES! to show content in below side navigation.','houzy')
      ),
      array(
        'id'      => 'sidenav-content',
        'type'    => 'select',
        'title'   => esc_html__('Side Navigation Content', 'houzy' ),
        'info'    => esc_html__('Select any section here.','houzy'),
		'options' => houzy_get_elementor_page_list(),
		'default' => '0'
      ),
    )
  ),
);


$page_settings_cpt = apply_filters( 'houzy_page_settings_cpt', true  );
if( $page_settings_cpt || !isset( $_GET['post'] )  ) {	

  $options[] = array(
    'id'        => '_tpl_default_settings',
    'title'     => esc_html__('Page Settings','houzy'),
    'post_type' => 'page',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => $page_settings
  );

}

// -----------------------------------------
// Post Metabox Options                    -
// -----------------------------------------
$post_meta_layout_section = $meta_layout_section;
$fields = $post_meta_layout_section['fields'];

	$fields[0]['title'] =  esc_html__('Post Layout', 'houzy' );
	unset( $fields[5] );
	unset( $post_meta_layout_section['fields'] );
	$post_meta_layout_section['fields']  = $fields;  

	$post_format_section = array(
		'name'  => 'post_format_data_section',
		'title' => esc_html__('Post Format', 'houzy'),
		'icon'  => 'fa fa-cog',
		'fields' =>  array(

			array(
				'id'           => 'single-post-style',
				'type'         => 'select',
				'title'        => esc_html__('Post Style', 'houzy'),
				'options'      => array(
          'breadcrumb-fixed'    => esc_html__('Breadcrumb Fixed', 'houzy'),
          'breadcrumb-parallax' => esc_html__('Breadcrumb Parallax', 'houzy'),
          'overlay'             => esc_html__('Overlay', 'houzy'),
          'overlap'             => esc_html__('Overlap', 'houzy'),          
          'custom-classic'      => esc_html__('Classic', 'houzy'),
          'custom-modern'       => esc_html__('Modern', 'houzy'), 
          'custom'              => esc_html__('Custom', 'houzy'),
				),
				'class'        => 'chosen',
				'default'      => 'overlap',
				'attributes'   => array(
				  'style'    => 'width: 50%;'
				),
				'info'         => esc_html__('Choose post style to display single post. If post style is "Custom", display based on Editor content.', 'houzy')
			),

			array(
			    'id'           => 'view_count',
			    'type'         => 'number',
			    'title'        => esc_html__('Views', 'houzy' ),
				  'info'         => esc_html__('No.of views of this post.', 'houzy'),
          'attributes' => array(
            'style'    => 'width: 15%;'
        	),
			),

			array(
			    'id'           => 'like_count',
			    'type'         => 'number',
			    'title'        => esc_html__('Likes', 'houzy' ),
				'info'         => esc_html__('No.of likes of this post.', 'houzy'),
	          	'attributes' => array(
		           'style'    => 'width: 15%;'
        	    ),
			),

			array(
				'id' => 'post-format-type',
				'title'   => esc_html__('Type', 'houzy' ),
				'type' => 'select',
				'default' => 'standard',
				'options' => array(
					'standard'  => esc_html__('Standard', 'houzy'),
					'status'	=> esc_html__('Status','houzy'),
					'quote'		=> esc_html__('Quote','houzy'),
					'gallery'	=> esc_html__('Gallery','houzy'),
					'image'		=> esc_html__('Image','houzy'),
					'video'		=> esc_html__('Video','houzy'),
					'audio'		=> esc_html__('Audio','houzy'),
					'link'		=> esc_html__('Link','houzy'),
					'aside'		=> esc_html__('Aside','houzy'),
					'chat'		=> esc_html__('Chat','houzy')
				),
				'info'         => esc_html__('Post Format & Type should be Same. Check the Post Format from the "Format" Tab, which comes in the Right Side Section', 'houzy'),
			),

			array(
				'id' 	  => 'post-gallery-items',
				'type'	  => 'gallery',
				'title'   => esc_html__('Add Images', 'houzy' ),
				'add_title'   => esc_html__('Add Images', 'houzy' ),
				'edit_title'  => esc_html__('Edit Images', 'houzy' ),
				'clear_title' => esc_html__('Remove Images', 'houzy' ),
				'dependency' => array( 'post-format-type', '==', 'gallery' ),
			),

			array(
				'id' 	  => 'media-type',
				'type'	  => 'select',
				'title'   => esc_html__('Select Type', 'houzy' ),
				'dependency' => array( 'post-format-type', 'any', 'video,audio' ),
		      	'options'	=> array(
					'oembed' => esc_html__('Oembed','houzy'),
					'self' => esc_html__('Self Hosted','houzy'),
				)
			),

			array(
				'id' 	  => 'media-url',
				'type'	  => 'textarea',
				'title'   => esc_html__('Media URL', 'houzy' ),
				'dependency' => array( 'post-format-type', 'any', 'video,audio' ),
			),
		)
	);

	$options[] = array(
		'id'        => '_dt_post_settings',
		'title'     => esc_html__('Post Settings','houzy'),
		'post_type' => 'post',
		'context'   => 'normal',
		'priority'  => 'high',
		'sections'  => array(
			$post_meta_layout_section,
			$meta_breadcrumb_section,
			$post_format_section			
		)
	);

// -----------------------------------------
// Tribe Events Post Metabox Options
// -----------------------------------------
  array_push( $post_meta_layout_section['fields'], array(
    'id' => 'event-post-style',
    'title'   => esc_html__('Post Style', 'houzy' ),
    'type' => 'select',
    'default' => 'type1',
    'options' => array(
      'type1'  => esc_html__('Classic', 'houzy'),
      'type2'  => esc_html__('Full Width','houzy'),
      'type3'  => esc_html__('Minimal Tab','houzy'),
      'type4'  => esc_html__('Clean','houzy'),
      'type5'  => esc_html__('Modern','houzy'),
    ),
	'class'    => 'chosen',
	'info'     => esc_html__('Your event post page show at most selected style.', 'houzy')
  ) );

  $options[] = array(
    'id'        => '_custom_settings',
    'title'     => esc_html__('Settings','houzy'),
    'post_type' => 'tribe_events',
    'context'   => 'normal',
    'priority'  => 'high',
    'sections'  => array(
      $post_meta_layout_section,
      $meta_breadcrumb_section
    )
  );


// -----------------------------------------
// Header And Footer Options Metabox
// -----------------------------------------
$post_types = apply_filters( 'houzy_header_footer_default_cpt' , array ( 'post', 'page' )  );
$options[] = array(
	'id'	=> '_dt_custom_settings',
	'title'	=> esc_html__('Header & Footer','houzy'),
	'post_type' => $post_types,
	'priority'  => 'high',
	'context'   => 'side', 
	'sections'  => array(

		# Header Settings
		array(
			'name'  => 'header_section',
			'title' => esc_html__('Header', 'houzy'),
			'icon'  => 'fa fa-angle-double-right',
			'fields' =>  array(

				# Header Show / Hide
				array(
					'id'		=> 'show-header',
					'type'		=> 'switcher',
					'title'		=> esc_html__('Show Header', 'houzy'),
					'default'	=>  true,
				),

				# Header
				array(
					'id'  		 => 'header',
					'type'  	 => 'select',
					'title' 	 => esc_html__('Choose Header', 'houzy'),
					'class'		 => 'chosen',
					'options'	 => 'posts',
					'query_args' => array(
						'post_type'	 => 'dt_headers',
						'orderby'	 => 'ID',
						'order'		 => 'ASC',
						'posts_per_page' => -1,
					),
					'default_option' => esc_attr__('Select Header', 'houzy'),
					'attributes' => array( 'style'	=> 'width:50%' ),
					'info'		 => esc_html__('Select custom header for this page.','houzy'),
					'dependency'	=> array( 'show-header', '==', 'true' )
				),							
			)			
		), # Header Settings

		# Footer Settings
		array(
			'name'  => 'footer_settings',
			'title' => esc_html__('Footer', 'houzy'),
			'icon'  => 'fa fa-angle-double-right',
			'fields' =>  array(
			
				# Footer Show / Hide
				array(
					'id'		=> 'show-footer',
					'type'		=> 'switcher',
					'title'		=> esc_html__('Show Footer', 'houzy'),
					'default'	=>  true,
				),
				
				# Footer
		        array(
					'id'         => 'footer',
					'type'       => 'select',
					'title'      => esc_html__('Choose Footer', 'houzy'),
					'class'      => 'chosen',
					'options'    => 'posts',
					'query_args' => array(
						'post_type'  => 'dt_footers',
						'orderby'    => 'ID',
						'order'      => 'ASC',
						'posts_per_page' => -1,
					),
					'default_option' => esc_attr__('Select Footer', 'houzy'),
					'attributes' => array( 'style'  => 'width:50%' ),
					'info'       => esc_html__('Select custom footer for this page.','houzy'),
					'dependency'    => array( 'show-footer', '==', 'true' )
				),			
			)			
		), # Footer Settings
	)	
);

DTMFramework_Metabox::instance( $options );