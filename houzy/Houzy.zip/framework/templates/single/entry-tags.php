<?php if ( ! defined( 'ABSPATH' ) ) { exit; }

	if( $post_Style == 'breadcrumb-fixed' ):
		the_tags( '<div class="tag-wrap"><span>'.esc_html__('A story about', 'houzy').'</span><p>', ' ', '</p></div>' );
	elseif( $post_Style == 'overlay' ):
		the_tags( '<span>'.esc_html__('Tags : ', 'houzy').'</span>', ', ', '' );
	elseif( $post_Style == 'overlap' ):
		?>
		<div class="tag-wrap">
			<?php the_tags( '<i class="fas fa-bookmark"> </i> ', ' ', '' ); ?>
		</div>
		<?php
	else:
		the_tags( '<i class="fas fa-bookmark"> </i> ', ' ', '' );
	endif; ?>