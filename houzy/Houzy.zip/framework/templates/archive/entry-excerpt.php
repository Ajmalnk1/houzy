<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

	<div class="entry-body"><?php echo houzy_excerpt( $excerpt_length );?></div>