<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

	<?php
	if( $post_Style == 'dt-sc-classic-ii-style' ):
		$title = get_the_title($post_ID);
		$title_exp = explode(' ', $title);
		$title_exp[count($title_exp)-1] = '<span>'.$title_exp[count($title_exp)-1].'</span>';
		$title = implode(' ', $title_exp);
		?>
		<h4>
			<?php if( is_sticky( $post_ID ) ) echo '<span class="sticky-post"><i class="fas fa-star"></i><span>'.esc_html__('Featured', 'houzy').'</span></span>'; ?>
			<a href="<?php echo get_permalink( $post_ID );?>" title="<?php printf(esc_attr__('Permalink to %s','houzy'), the_title_attribute('echo=0'));?>"><?php echo "{$title}"; ?></a>
		</h4>
		<?php
	else:
		?>
		<h4>
			<?php if( is_sticky( $post_ID ) ) echo '<span class="sticky-post"><i class="fas fa-star"></i><span>'.esc_html__('Featured', 'houzy').'</span></span>'; ?>
			<a href="<?php echo get_permalink( $post_ID );?>" title="<?php printf(esc_attr__('Permalink to %s','houzy'), the_title_attribute('echo=0'));?>"><?php the_title();?></a>
		</h4>
		<?php
	endif;
	?>