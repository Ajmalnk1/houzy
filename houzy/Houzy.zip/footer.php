    <?php
        /**
         * houzy_hook_content_after hook.
         * 
         */
        do_action( 'houzy_hook_content_after' );
    ?>

        <!-- **Footer** -->
        <footer id="footer">
            <div class="container">
            <?php
                /**
                 * houzy_footer hook.
                 * 
                 * @hooked houzy_ele_footer_template - 10
                 *
                 */
                do_action( 'houzy_footer' );
            ?>
            </div>
        </footer><!-- **Footer - End** -->

    </div><!-- **Inner Wrapper - End** -->
        
</div><!-- **Wrapper - End** -->
<?php
    
    do_action( 'houzy_hook_bottom' );

    wp_footer();
?>
</body>
</html>