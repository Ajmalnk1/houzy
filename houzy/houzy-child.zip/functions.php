<?php
add_action( 'wp_enqueue_scripts', 'houzy_child_enqueue_styles', 100);
function houzy_child_enqueue_styles() {
	wp_enqueue_style( 'houzy-parent', get_theme_file_uri('/style.css') );
}